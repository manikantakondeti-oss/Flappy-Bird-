# Flappy Bird Game in C

A graphical Flappy Bird game built in C with the raylib graphics library.

## Features

- Gravity and flap controls
- Randomly positioned pipe gaps
- Collision detection
- Score and best-score display
- Moving clouds, shaded pipes, animated wing, and textured ground
- Start, game-over, and restart screens
- Persistent high-score storage using highscore.txt
- File handling using fopen(), fscanf(), fprintf(), and fclose()

## Requirements

- macOS
- Homebrew
- raylib

Install raylib once:

```bash
brew install raylib
```

## Run the game

Open Terminal in this folder and run:

```bash
make run
```

To compile without launching the game:

```bash
make
```

## Controls

- `Space` or `Up Arrow` — flap
- `R` — restart after game over
- Close the game window — exit

## Project files

- `flappy_bird.c` — complete game source code
- `Makefile` — compile, run, and clean commands

## C concepts used

- Structures and arrays
- Functions
- Loops and conditions
- Random number generation
- Collision detection
- Real-time keyboard input
- Graphics with raylib
