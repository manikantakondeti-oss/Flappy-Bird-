/*
 * Graphical Flappy Bird in C using raylib
 * Run `make run` after installing raylib.
 */

#include "raylib.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <stdio.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 560
#define GROUND_Y 500
#define BIRD_X 180
#define PIPE_WIDTH 78
#define PIPE_GAP 155
#define PIPE_COUNT 3

typedef enum { START, PLAYING, GAME_OVER } GameState;

typedef struct {
    float x;
    int gap_y;
    bool scored;
} Pipe;

static int new_gap_y(void)
{
    return GetRandomValue(120, GROUND_Y - PIPE_GAP - 45);
}

static float clamp_float(float value, float minimum, float maximum)
{
    if (value < minimum) return minimum;
    if (value > maximum) return maximum;
    return value;
}

static void reset_game(Pipe pipes[], float *bird_y, float *velocity, int *score)
{
    int i;
    *bird_y = 250.0f;
    *velocity = 0.0f;
    *score = 0;
    for (i = 0; i < PIPE_COUNT; i++) {
        pipes[i].x = 550.0f + i * 270.0f;
        pipes[i].gap_y = new_gap_y();
        pipes[i].scored = false;
    }
}

static bool bird_hits_pipe(float bird_y, const Pipe *pipe)
{
    const int bird_radius = 18;
    bool in_pipe_x = BIRD_X + bird_radius > pipe->x &&
                     BIRD_X - bird_radius < pipe->x + PIPE_WIDTH;
    bool in_gap = bird_y - bird_radius > pipe->gap_y &&
                  bird_y + bird_radius < pipe->gap_y + PIPE_GAP;
    return in_pipe_x && !in_gap;
}

static bool update_game(Pipe pipes[], float *bird_y, float *velocity, int *score)
{
    int i;
    const float pipe_speed = 170.0f;

    *velocity += 730.0f * GetFrameTime();       /* gravity */
    *bird_y += *velocity * GetFrameTime();
    for (i = 0; i < PIPE_COUNT; i++) {
        pipes[i].x -= pipe_speed * GetFrameTime();
        if (!pipes[i].scored && pipes[i].x + PIPE_WIDTH < BIRD_X) {
            pipes[i].scored = true;
            (*score)++;
        }
        if (pipes[i].x + PIPE_WIDTH < 0) {
            float furthest = pipes[0].x;
            int j;
            for (j = 1; j < PIPE_COUNT; j++)
                if (pipes[j].x > furthest) furthest = pipes[j].x;
            pipes[i].x = furthest + 270.0f;
            pipes[i].gap_y = new_gap_y();
            pipes[i].scored = false;
        }
        if (bird_hits_pipe(*bird_y, &pipes[i])) return false;
    }
    return *bird_y > 18 && *bird_y < GROUND_Y - 18;
}

static void draw_pipe(const Pipe *pipe)
{
    int x = (int)pipe->x;
    Color pipe_green = (Color){ 71, 171, 69, 255 };
    Color pipe_shadow = (Color){ 35, 110, 47, 255 };
    Color pipe_light = (Color){ 119, 207, 90, 255 };

    /* Shading makes the pipes look less flat. */
    DrawRectangle(x, 0, PIPE_WIDTH, pipe->gap_y, pipe_green);
    DrawRectangle(x, 0, 12, pipe->gap_y, pipe_light);
    DrawRectangle(x + PIPE_WIDTH - 12, 0, 12, pipe->gap_y, pipe_shadow);
    DrawRectangle(x - 7, pipe->gap_y - 19, PIPE_WIDTH + 14, 19, pipe_green);
    DrawRectangle(x - 7, pipe->gap_y - 19, 12, 19, pipe_light);
    DrawRectangle(x + PIPE_WIDTH - 5, pipe->gap_y - 19, 12, 19, pipe_shadow);

    DrawRectangle(x, pipe->gap_y + PIPE_GAP, PIPE_WIDTH,
                  GROUND_Y - (pipe->gap_y + PIPE_GAP), pipe_green);
    DrawRectangle(x, pipe->gap_y + PIPE_GAP, 12,
                  GROUND_Y - (pipe->gap_y + PIPE_GAP), pipe_light);
    DrawRectangle(x + PIPE_WIDTH - 12, pipe->gap_y + PIPE_GAP, 12,
                  GROUND_Y - (pipe->gap_y + PIPE_GAP), pipe_shadow);
    DrawRectangle(x - 7, pipe->gap_y + PIPE_GAP, PIPE_WIDTH + 14, 19, pipe_green);
    DrawRectangle(x - 7, pipe->gap_y + PIPE_GAP, 12, 19, pipe_light);
    DrawRectangle(x + PIPE_WIDTH - 5, pipe->gap_y + PIPE_GAP, 12, 19, pipe_shadow);
}

static void draw_centered(const char *text, int y, int size, Color color)
{
    DrawText(text, (SCREEN_WIDTH - MeasureText(text, size)) / 2, y, size, color);
}

static void draw_cloud(float x, float y, float scale)
{
    Color cloud = Fade(RAYWHITE, 0.82f);
    DrawCircle((int)x, (int)y, (int)(18 * scale), cloud);
    DrawCircle((int)(x + 24 * scale), (int)(y - 8 * scale), (int)(24 * scale), cloud);
    DrawCircle((int)(x + 52 * scale), (int)y, (int)(19 * scale), cloud);
    DrawRectangle((int)(x - 17 * scale), (int)y, (int)(88 * scale), (int)(20 * scale), cloud);
}

static void draw_background(void)
{
    float time = (float)GetTime();
    float cloud_1 = fmodf(810.0f - time * 18.0f, 980.0f) - 100.0f;
    float cloud_2 = fmodf(520.0f - time * 12.0f, 1050.0f) - 100.0f;
    float cloud_3 = fmodf(980.0f - time * 24.0f, 1120.0f) - 100.0f;

    DrawRectangleGradientV(0, 0, SCREEN_WIDTH, GROUND_Y,
                           (Color){ 97, 199, 247, 255 }, (Color){ 177, 229, 249, 255 });
    draw_cloud(cloud_1, 105, 0.85f);
    draw_cloud(cloud_2, 210, 0.65f);
    draw_cloud(cloud_3, 55, 0.55f);
}

static void draw_bird(float bird_y, float velocity)
{
    float wing_offset = sinf((float)GetTime() * 18.0f) * 4.0f;
    float tilt = clamp_float(velocity * 0.045f, -18.0f, 25.0f);

    /* A small rotation makes upward and downward motion feel more natural. */
    DrawCircle(BIRD_X, (int)bird_y, 20, (Color){ 251, 211, 61, 255 });
    DrawCircleLines(BIRD_X, (int)bird_y, 20, (Color){ 203, 144, 28, 255 });
    DrawEllipse(BIRD_X - 6, (int)(bird_y + 7 + wing_offset), 12, 7, ORANGE);
    DrawCircle(BIRD_X + 8, (int)bird_y - 7, 6, RAYWHITE);
    DrawCircle(BIRD_X + 10, (int)bird_y - 7, 2, BLACK);
    DrawTriangle((Vector2){ BIRD_X + 18, bird_y - 2 },
                 (Vector2){ BIRD_X + 32, bird_y + 5 + tilt * 0.1f },
                 (Vector2){ BIRD_X + 18, bird_y + 10 }, ORANGE);
}

static void draw_ground(void)
{
    int x;
    DrawRectangle(0, GROUND_Y, SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_Y, (Color){ 225, 196, 97, 255 });
    DrawRectangle(0, GROUND_Y, SCREEN_WIDTH, 10, (Color){ 95, 174, 58, 255 });
    for (x = 10; x < SCREEN_WIDTH; x += 38)
        DrawCircle(x, GROUND_Y + 30 + (x % 3) * 8, 3, (Color){ 196, 164, 75, 255 });
}

static void draw_game(const Pipe pipes[], float bird_y, float velocity, int score, int best_score)
{
    int i;
    draw_background();
    for (i = 0; i < PIPE_COUNT; i++) draw_pipe(&pipes[i]);
    draw_bird(bird_y, velocity);
    draw_ground();
    DrawText(TextFormat("Score: %d", score), 28, 24, 30, RAYWHITE);
    DrawText(TextFormat("Best: %d", best_score), 28, 59, 19, RAYWHITE);
}

static int load_best_score(void)
{
    FILE *file;
    int best = 0;

    file = fopen("highscore.txt", "r");

    if (file != NULL)
    {
        if (fscanf(file, "%d", &best) != 1 || best < 0)
            best = 0;

        fclose(file);
    }

    return best;
}

static void save_best_score(int best)
{
    FILE *file;

    file = fopen("highscore.txt", "w");

    if (file != NULL)
    {
        fprintf(file, "%d", best);
        fclose(file);
    }
}


int main(void)
{
    Pipe pipes[PIPE_COUNT];
    float bird_y, velocity;
    int score;
    int best_score;
    GameState state = START;

    srand((unsigned int)time(NULL));
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Flappy Bird - C Project");
    SetTargetFPS(60);
    reset_game(pipes, &bird_y, &velocity, &score);
    best_score = load_best_score();

    while (!WindowShouldClose()) {
        bool flap = IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_UP);
        if (state == START && flap) {
            state = PLAYING;
            velocity = -310.0f;
        } else if (state == PLAYING) {
            if (flap) velocity = -310.0f;
            if (!update_game(pipes, &bird_y, &velocity, &score)) {
             if (score > best_score) {
              best_score = score;
              save_best_score(best_score);
    }

         state = GAME_OVER;
}
        } else if (state == GAME_OVER && IsKeyPressed(KEY_R)) {
            reset_game(pipes, &bird_y, &velocity, &score);
            state = START;
        }

        BeginDrawing();
        draw_game(pipes, bird_y, velocity, score, best_score);
        if (state == START) {
            DrawRectangle(175, 185, 450, 135, Fade(BLACK, 0.65f));
            draw_centered("FLAPPY BIRD", 205, 40, YELLOW);
            draw_centered("Press SPACE or UP ARROW to flap", 265, 21, RAYWHITE);
        } else if (state == GAME_OVER) {
            DrawRectangle(185, 190, 430, 135, Fade(BLACK, 0.72f));
            draw_centered("GAME OVER", 210, 38, RED);
            draw_centered(TextFormat("Score: %d   Best: %d", score, best_score), 263, 22, YELLOW);
            draw_centered("Press R to play again", 295, 19, RAYWHITE);
        }
        EndDrawing();
    }
    CloseWindow();
    return 0;
}
